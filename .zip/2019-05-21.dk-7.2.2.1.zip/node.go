// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package xcc

import (
//	fmt
)

// ===========================================================================

// item represents an item.
type item struct {
	id string
	prev, next int
}

func (a item) String() string {
	return a.id
}

// ===========================================================================

// opta represents an option - somthing one can 'optare' (=choose) from.
type opta struct {
	root, prev, next int
}

// Note: Following methods intend to clarify some semantics.
// For performance reasons they are not called later on but inlined directly.

// Col returns the column index.
//
// Applicable to optaS[i] for i > len(itemS)..
func (a opta) Col() int {
	return a.root
}

// Size returns the size / length of a column.
//
// Applicable to optaS[i] for 0 <= i <= len(itemS).
func (a opta) Size() int {
	return a.root
}

func (a opta) Up() int {
	return a.prev
}

func (a opta) Down() int {
	return a.next
}

// ===========================================================================

type itemS []item

type optaS []opta

// Append id into doubly linked list rooted at 0.
func (a itemS) Append(id string) itemS {
	c := len(a)                 // shall create a[c]
	p := c - 1                  // prev
	a[p].next, a[0].prev = c, c // adjust existing prev.next & root.prev

	return append(a, item{prev: p, id: id})
}

// Append another root. 
func (a optaS) Append() optaS {
	c := len(a)                 // shall create a[c]
	return append(a, opta{prev: c, next: c})
}

// AppOpt appends another option to the list for the item rooted at I. 
func (a optaS) AppOpt(I int) optaS {
	c := len(a)                 // shall create a[c]
	p := a[I].prev              // prev
	a[p].next, a[I].prev = c, c // adjust existing prev.next & root.prev
	a[I].root++                 // incr #-of-options for in root-item[I]

	return append(a, opta{prev: p, next: I, root:I})
}

// ===========================================================================

// m represents a (usually sparse) matrix representation of some exact cover problem XCC.
//
// Note: The null value is NOT useful!
type m struct {
	prim  int // the first #prim items are primary, to be covered exactly once; the remaining (if any) are secondary, to be covered at most once.
	itemS     // the items.
	optaS     // the options.
}

// ===========================================================================
// Clone

// Clone returns a new slice consisting of a copy of the data of a.
func (a itemS) Clone() itemS {
	i := make([]item, len(a))
	copy(i, a[:len(a)])
	return i
}

// Clone returns a new slice consisting of a copy of the data of a.
func (a optaS) Clone() optaS {
	i := make([]opta, len(a))
	copy(i, a[:len(a)])
	return i
}

// Clone returns a new matrix consisting of a copy of the data of a.
func (a m) Clone() (matrix m) {
	matrix.prim = a.prim
	matrix.itemS = a.itemS.Clone()
	matrix.optaS = a.optaS.Clone()
	return
}

/* ===========================================================================
Some notes about structure and invariants of some matrix `a` built with `items`:

	N := len(items)      // # of items
	I := len(a.itemS)    // len
	Z := len(a.optaS) -1 // index of last spacer

	I == N + 1
	N == I - 1

	N == a.itemS[0].root
	N == a.optaS[0].root // DK leaves a.optaS[0] alone; we build in tandem

	a.itemS[0].next == index of first item iff != 0
	a.itemS[0].prev == index of last item iff != 0

	a.optaS[I] is the first spacer. Thus:
	a.optaS[I].root == 0

	a.optaS[Z] is the last spacer. Thus:
	a.optaS[Z].root == # option-lines * -1

	// traverse items:
	for i := a.itemS[0].next; i != 0; i = a.itemS[i].next {
		a.optaS[i] represents 'the-column-root':
		a.optaS[i].root == len(options-with-i)
		a.optaS[i].next == index of first option-with-i
		a.optaS[i].prev == index of last  option-with-i

		for x := a.optaS[i].next; x > ???; x = a.optaS[x].next {
			a.optaS[x] represents the first option with item[i]
		}
	}

// ===========================================================================
*/

type dict map[string]int

func (a dict) learnOnce(item string, index int) dict {
	if i, ok := a[item]; ok {
		_ = i // TODO: show data: item, i, index
		panic("duplicate item encountered.")
	}

	a[item] = index
	return a
}

func (a dict) mustKnow(item string) (index int) {
	index, ok := a[item]
	if !ok {
		panic("item unknown.")
	} // TODO: show data: item, i, index
	return
}

// ===========================================================================

// P represents a problem under construction.
//
// Intended use (simplified):
//   p := Items(0, "a", "b", "c", "d")
//   p.AddOption("a", "b")
//   p.AddOption("a", "c")
//   p.AddOption("c", "d")
//   ...
//   go p.S().Dance()
//   go p.S().Dance()
//   go p.S().Dance()
//   ...
//
// Note: The null value is NOT useful!

type P struct {
	m    // the matrix.
	dict // lookup item.ID - must be unique.
}

// M returns (a clone of) the matrix.
func (a *P) M() m {
	return a.m.Clone()
}

// Items returns a new problem matrix
// populateded with the given items and
// ready to accept options.
//
// The first `primaries` items are primary, to be covered exactly once; the remaining (if any) are secondary, to be covered at most once.
//
// For convenience, `primaries` is adjusted
// to len(items) iff < 1 or > len(items).
//
// It panics iff no items are provided,
// or iff some duplicate item is encountered,
// or iff some item is an empty string.
func Items(primaries int, items ...string) *P {
	N := len(items)
	if N < 1 {
		panic("one item needed, at least.")
	}

	// adjust primaries
	if primaries == 0 || primaries < 0 || primaries > N {
		primaries = N
	}

	N++ // allocate one more: for root

	problem := P{
		m{
			primaries,
			make([]item, 0, N),
			make([]opta, 0, N*N), // pre-allocate generously; subsequent Clone will cut the fat
		},
		make(map[string]int, N),
	}

	// make the root
	var id string // = "": empty id for root
	problem.learn(id)
	problem.itemS = append(problem.itemS, item{id: id})
	problem.optaS = append(problem.optaS, opta{})

	// push the items
	for _, id := range items {
		problem.learn(id) // panics on duplicate
		problem.itemS = problem.itemS.Append(id)
		problem.optaS = problem.optaS.Append()
	}

	problem.optaS = append(problem.optaS, opta{}) // add trailing spacer

	return &problem
}

func (a *P) learn(item string) {
	a.dict = a.dict.learnOnce(item, len(a.itemS))
}

// AddOption returns the extended problem - thus calls may be chained.
func (a *P) AddOption(items ...string) *P {
	Z := len(a.optaS) - 1 // index of last spacer

	// update preceeding spacer
	a.optaS[Z].next = Z + len(items)

	for _, id := range items {
		I := a.dict.mustKnow(id)    // index of item
		a.optaS = a.optaS.AppOpt(I) // append as item-column
	}

	r := a.optaS[Z].root - 1
	a.optaS = append(a.optaS, opta{root: r, prev: Z + 1}) // add trailing spacer

	return a
}

// S returns an instance searchable for solutions - ready to dance.
//
// Note: each result obtained is a fresh clone - safe for concurrent use by another go routine.
func (a *P) S(items ...string) *S {
	s := S{
		a.m.Clone(),
		[]opta{},
	}
	return &s
}

// ===========================================================================

// path represents a search constellation - a (partial) solution.
type path []opta

// Note: some people use a stack

// append an opta: aka Push
func (a path) append(o opta) path {
	return append(a, o)
}

// forget last opta: aka Drop
func (a path) dotdot() path {
	return a[:len(a)-1]
}

// ===========================================================================

// S represents a problem under investigation while searching for solutions.
//
// Note: The null value is NOT useful!
type S struct {
	m    // the matrix.
	path // the path to solution.
}

// M returns (a clone of) the matrix.
func (a S) M() m {
	return a.m.Clone()
}

// Peek returns the current path.
//
// The result is intended for quick checks only,
// must NOT be modified
// and is NOT safe for concurrent use!
func (a S) Peek() path {
	return a.path
}

// Path returns (a clone of) the current path.
//
// Thus, the returned path is safe for concurrent use.
func (a S) Path() (path path) {
	copy(path, a.path)
	return
}

// ===========================================================================
