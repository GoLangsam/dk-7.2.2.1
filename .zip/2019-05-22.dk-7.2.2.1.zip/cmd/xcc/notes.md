
- XC eXact Cover
	- Algorithm X
		- Choose(i): MRV heuristic: first item with smallest # of (remaining) options.

- XCC eXact Covering with Colors
	- Algorithm C

++ XCC
- add Color to opta, Color c in [1..C]
