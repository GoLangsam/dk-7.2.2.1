// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// xc implements the excat cover via dansing links
package xc

//	fmt

// ===========================================================================

// item has a unique id and represents
// a member of a doubly linked list
// implemented as a ring with a sentiel root
// hosted in a slice.
type item struct {
	id         string // unique
	prev, next int    // pointer-indices
}

// String returns the id.
func (a item) String() string {
	return a.id
}

// ===========================================================================

// opta represents an option - somthing one can 'optare' (=choose) from.
type opta struct {
	root, prev, next int
}

// ===========================================================================

// itemS represents a collection of items.
type itemS []item

// optaS represents a collection of optas.
type optaS []opta

// AddItem appends another id into doubly linked list rooted at 0.
func (a itemS) AddItem(id string) itemS {
	c := len(a)                 // shall create a[c]
	p := c - 1                  // prev
	a[p].next, a[0].prev = c, c // adjust existing prev.next & root.prev

	return append(a, item{prev: p, id: id})
}

// AddItem appends another item root.
func (a optaS) AddItem() optaS {
	c := len(a) // shall create a[c]
	return append(a, opta{prev: c, next: c})
}

// AddOpta appends another option to the list for the item rooted at I.
func (a optaS) AddOpta(I int) optaS {
	c := len(a)                 // shall create a[c]
	p := a[I].prev              // prev
	a[p].next, a[I].prev = c, c // adjust existing prev.next & root.prev
	a[I].root++                 // incr #-of-options for in root-item[I]

	return append(a, opta{prev: p, next: I, root: I})
}

// ===========================================================================

// m represents a (usually sparse) matrix representation of some exact cover problem XCC.
//
// Note: The null value is NOT useful!
type m struct {
	prim  int // the first #prim items are primary, to be covered exactly once; the remaining (if any) are secondary, to be covered at most once.
	itemS     // the items.
	optaS     // the options.
}

// ===========================================================================
// Clone

// Clone returns a new slice consisting of a copy of the data of a.
func (a itemS) Clone() itemS {
	i := make([]item, len(a))
	copy(i, a[:len(a)])
	return i
}

// Clone returns a new slice consisting of a copy of the data of a.
func (a optaS) Clone() optaS {
	i := make([]opta, len(a))
	copy(i, a[:len(a)])
	return i
}

// Clone returns a new matrix consisting of a copy of the data of a.
func (a m) Clone() (matrix m) {
	matrix.prim = a.prim
	matrix.itemS = a.itemS.Clone()
	matrix.optaS = a.optaS.Clone()
	return
}

// ===========================================================================
// Note: Following methods intend to clarify some semantics.
// For performance reasons they are not called later on but inlined directly.

// Col returns the column index.
//
// Applicable to optaS[i] for i > len(itemS)..
func (a opta) Col() int {
	return a.root
}

// Size returns the size / length of a column.
//
// Applicable to optaS[i] for 0 <= i <= len(itemS).
func (a opta) Size() int {
	return a.root
}

func (a opta) Up() int {
	return a.prev
}

func (a opta) Down() int {
	return a.next
}

/* ===========================================================================
Some notes about structure and invariants of some matrix `a` built with `items`:

	N := len(items)      // # of items
	I := len(a.itemS)    // len
	Z := len(a.optaS) -1 // index of last spacer

	I == N + 1
	N == I - 1

	N == a.itemS[0].root
	N == a.optaS[0].root // DK leaves a.optaS[0] alone; we build in tandem

	a.itemS[0].next == index of first item iff != 0
	a.itemS[0].prev == index of last item iff != 0

	a.optaS[I] is the first spacer. Thus:
	a.optaS[I].root == 0

	a.optaS[Z] is the last spacer. Thus:
	a.optaS[Z].root == # option-lines * -1

	// traverse items:
	for i := a.itemS[0].next; i != 0; i = a.itemS[i].next {
		a.optaS[i] represents 'the-column-root':
		a.optaS[i].root == len(options-with-i)
		a.optaS[i].next == index of first option-with-i
		a.optaS[i].prev == index of last  option-with-i

		for x := a.optaS[i].next; x > ???; x = a.optaS[x].next {
			a.optaS[x] represents the first option with item[i]
		}
	}

*/

// ===========================================================================

// dict
type dict map[string]int

// learnOnce registers some id and its index,
// and panics iff the id is already known.
func (a dict) learnOnce(id string, index int) dict {
	if i, ok := a[id]; ok {
		_ = i // TODO: show data: id, i, index
		panic("duplicate id encountered.")
	}

	a[id] = index
	return a
}

// mustKnow
func (a dict) mustKnow(id string) (index int) {
	index, ok := a[id]
	if !ok {
		panic("unknown id.")
	} // TODO: show data: id
	return
}

// ===========================================================================

// P represents a problem under construction.
//
// Note: The null value is NOT useful!
type P struct {
	m    // the matrix.
	dict // lookup item.id - must be unique.
}

// Items returns a new problem matrix
// populateded with the given items and
// ready to accept options.
//
// The first `primaries` items are primary, to be covered exactly once; the remaining (if any) are secondary, to be covered at most once.
//
// For convenience, `primaries` is adjusted
// to len(items) iff < 1 or > len(items).
//
// It panics iff no items are provided,
// or iff some duplicate item is encountered,
// or iff some item is an empty string.
func Items(primaries int, items ...string) *P {
	N := len(items)
	if N < 1 {
		panic("need one item at least.")
	}

	if primaries == 0 || primaries > N || primaries < 0 {
		primaries = N // adjust primaries
	}

	N++ // allocate one more: for root

	problem := P{
		m{
			primaries,
			make([]item, 0, N),
			make([]opta, 0, N*N), // pre-allocate generously; subsequent Clone will cut the fat
		},
		make(map[string]int, N),
	}

	// make the root
	var id string // = "": empty id for root
	problem.learn(id)
	problem.itemS = append(problem.itemS, item{id: id})
	problem.optaS = append(problem.optaS, opta{})

	// push the items - in tandem
	for _, id := range items {
		problem.learn(id) // panics on duplicate
		problem.itemS = problem.itemS.AddItem(id)
		problem.optaS = problem.optaS.AddItem()
	}

	// add trailing spacer
	problem.optaS = append(problem.optaS, opta{})

	return &problem
}

func (a *P) learn(item string) {
	a.dict = a.dict.learnOnce(item, len(a.itemS))
}

// AddOption returns the extended problem - thus calls may be chained.
func (a *P) AddOption(items ...string) *P {
	Z := len(a.optaS) - 1 // index of last spacer

	// update preceeding spacer
	a.optaS[Z].next = Z + len(items)

	for _, id := range items {
		I := a.dict.mustKnow(id)     // index of item
		a.optaS = a.optaS.AddOpta(I) // append as item-column
	}

	// add trailing spacer
	r := a.optaS[Z].root - 1
	a.optaS = append(a.optaS, opta{root: r, prev: Z + 1})

	return a
}

// M returns (a clone of) the matrix.
func (a *P) M() m {
	return a.m.Clone()
}

// S returns an instance searchable for solutions - ready to dance.
//
// Note: each result obtained is a fresh clone - safe for concurrent use by another go routine.
func (a *P) S(items ...string) *S {
	s := S{
		a.m.Clone(),
		[]opta{},
	}
	return &s
}

// ===========================================================================

// path represents a search constellation - a (partial) solution.
type path []opta

// Note: some people use a stack

// AppEnd some opta: aka stack.Push(...)
func (a path) AppEnd(o opta) path {
	return append(a, o)
}

// DotDot forgets the last opta: aka stack.Drop(), or path "..".
func (a path) DotDot() path {
	return a[:len(a)-1]
}

// Peek returns the current path.
//
// The result is intended for quick checks only,
// must NOT be modified
// and is NOT safe for concurrent use!
func (a path) Peek() path {
	return a
}

// Path returns (a clone of) the current path.
//
// Thus, the returned path is safe for concurrent use.
func (a path) Path() path {
	p := make([]opta, len(a))
	copy(p, a)
	return p
}

// ===========================================================================

// S represents a problem under investigation: searching for solutions.
//
// Note: The null value is NOT useful!
type S struct {
	m    // the matrix.
	path // the search path to solution.
	// TODO: add counters: global and per-level
}

// M returns (a clone of) the matrix.
func (a S) M() m {
	return a.m.Clone()
}

// ===========================================================================
