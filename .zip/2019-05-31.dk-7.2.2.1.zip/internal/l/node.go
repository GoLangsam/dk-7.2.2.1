// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package l


// ===========================================================================

type Node interface {
	Next() int
	Prev() int
	Root() int
	SetN(int)
	SetP(int)
	SetR(int)
}

// ===========================================================================

type BiLi struct {
	Prv, Nxt int
}

func (a BiLi) Next() int {return a.Nxt}
func (a BiLi) Prev() int {return a.Prv}
func (a BiLi) Root() int {panic("I do not know about root")}

func (a BiLi) SetN(link int) {a.Nxt = link}
func (a BiLi) SetP(link int) {a.Prv = link}
func (a BiLi) SetR(link int) {panic("I do not know about root")}


// ===========================================================================

type SpMa struct {
	Rot int
	BiLi
}

func (a SpMa) Root() int {return a.Rot}
func (a SpMa) SetR(link int) {a.Rot = link}

// ===========================================================================
