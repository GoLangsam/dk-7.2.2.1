// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package x

// ===========================================================================

// Opta represents an option - somthing one can 'optare' (=choose) from.
type Opta struct {
	Root Index
	Item
}

// ===========================================================================

// OptaS represents a collection of optas.
type OptaS []Opta

// ===========================================================================

// Optas represents a collection of optas with a lookup dictionary.
type Optas struct {
	OptaS
	*Dict
}

// ===========================================================================

// Clone returns a new slice consisting of a copy of the data of a.
func (a OptaS) Clone() OptaS {
	c := make([]Opta, len(a))
	copy(c, a)
	return c
}

// ===========================================================================

// AddItem appends another option root.
func (a OptaS) AddItem(root Index) OptaS {
	c := len(a) // shall create a[c]

	return append(a, Opta{Item: Item{Prev: c, Next: c}, Root: root})
}

// AddOpta appends another option to the list for the Item Rooted at root.
func (a OptaS) AddOpta(root Index) OptaS {
	c := len(a)                    // shall create a[c]
	p := a[root].Prev              // Prev
	a[p].Next, a[root].Prev = c, c // adjust existing Prev.Next & Root.Prev
	a[root].Root++                 // incr #-of-options for in Root-Item[root]

	return append(a, Opta{Item: Item{Prev: p, Next: root}, Root: root})
}

// ===========================================================================
// Note: Following methods intend to clarify some semantics.
// For performance reasons they are not called elsewhere but inlined directly.

// Col returns the column index.
//
// Applicable to OptaS[i] for i > len(ItemS)..
func (a Opta) Col() Index {
	return a.Root
}

// Size returns the size / length of a column.
//
// Applicable to OptaS[i] for 0 <= i <= len(ItemS).
func (a Opta) Size() Index {
	return a.Root
}

func (a Opta) Up() Index {
	return a.Prev
}

func (a Opta) Down() Index {
	return a.Next
}

// ===========================================================================
