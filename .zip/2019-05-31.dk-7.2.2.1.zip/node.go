// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// xc implements the excat cover via dancing links
package xc

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

//	fmt

// ===========================================================================

// m represents a (usually sparse) matrix representation of some exact cover problem XCC.
//
// Note: The null value is NOT useful!
type m struct {
	prim    int // the first #prim items are primary, to be covered exactly once; the remaining (if any) are secondary, to be covered at most once.
	x.NameS     // the names
	x.ItemS     // the items.
	x.OptaS     // the options.
}

// ===========================================================================
// Clone

// Clone returns a new matrix consisting of a copy of the data of a.
func (a m) Clone() (matrix m) {
	matrix.prim = a.prim
	matrix.NameS = a.NameS.Clone()
	matrix.ItemS = a.ItemS.Clone()
	matrix.OptaS = a.OptaS.Clone()
	return
}

// ===========================================================================

// P represents a problem under construction.
//
// Note: The null value is NOT useful!
type P struct {
	m      // the matrix.
	x.Dict // lookup Item.name - must be unique.
}

// Items returns a new problem matrix
// populateded with the given items and
// ready to accept options.
//
// The first `primaries` items are primary, to be covered exactly once; the remaining (if any) are secondary, to be covered at most once.
//
// For convenience, `primaries` is adjusted
// to len(items) iff < 1 or > len(items).
//
// It panics iff no items are provided,
// or iff some duplicate Item is encountered,
// or iff some Item is an empty string.
func Items(primaries int, items ...string) *P {
	N := len(items)
	if N < 1 {
		panic("need one Item at least.")
	}

	if primaries == 0 || primaries > N || primaries < 0 {
		primaries = N // adjust primaries
	}

	N++ // allocate one more: for root

	problem := P{
		m{
			primaries,
			make([]x.Name, 0, N),
			make([]x.Item, 0, N),
			make([]x.Opta, 0, N*N), // pre-allocate generously; subsequent Clone will cut the fat
		},
		make(map[string]int, N),
	}

	// make the root
	var id string              // = "": empty id for root
	root := len(problem.ItemS) // should be 0
	problem.learn(id)
	problem.NameS = append(problem.NameS, x.Name(id))
	problem.ItemS = append(problem.ItemS, x.Item{})
	problem.OptaS = append(problem.OptaS, x.Opta{})

	// push the items - in tandem
	for _, id := range items {
		problem.learn(id) // panics on duplicate
		problem.NameS = problem.NameS.AddName(id)
		problem.ItemS = problem.ItemS.AddItem(root)
		problem.OptaS = problem.OptaS.AddItem(root)
	}

	// add trailing spacer
	problem.OptaS = append(problem.OptaS, x.Opta{})

	return &problem
}

func (a *P) learn(Item string) {
	a.Dict = a.Dict.LearnOnce(Item, len(a.ItemS))
}

// AddOption returns the extended problem - thus calls may be chained.
func (a *P) AddOption(items ...string) *P {
	Z := len(a.OptaS) - 1 // index of last spacer

	// update preceeding spacer
	a.OptaS[Z].Next = Z + len(items)

	for _, name := range items {
		root := a.Dict.MustKnow(name)   // index of Item
		a.OptaS = a.OptaS.AddOpta(root) // append as Item-column
	}

	// add trailing spacer
	root := a.OptaS[Z].Root - 1
	a.OptaS = append(a.OptaS, x.Opta{Item: x.Item{Prev: Z + 1}, Root: root})

	return a
}

// M returns (a clone of) the matrix.
func (a *P) M() m {
	return a.m.Clone()
}

// S returns an instance searchable for solutions - ready to dance.
//
// Note: each result obtained is a fresh clone - safe for concurrent use by another go routine.
func (a *P) S(items ...string) *S {
	s := S{
		a.m.Clone(),
		make([]int, 0, a.prim), // allocate worst case size - hope this makes Tom more happy :-)
	}
	return &s
}

// ===========================================================================

// S represents a problem under investigation: searching for solutions.
//
// Note: The null value is NOT useful!
type S struct {
	m      // the matrix.
	x.LiFo // the search path to solution.
	// TODO: add counters: global and per-level
	// TODO: add functionpointers for non-default handling: tick, search col, filterfn for search, ...
	// TODO: implement dance & co.
}

// M returns (a clone of) the matrix.
func (a S) M() m {
	return a.m.Clone()
}

// ===========================================================================
