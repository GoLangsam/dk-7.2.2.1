
- XC eXact Cover
	- Algorithm X
		- Choose(i): MRV heuristic: first item with smallest # of (remaining) options.

- XCC eXact Covering with Colors
	- Algorithm C

++ XCC
- add Color to opta, Color c in [1..C]
  as parallel array type C []Color

+ API
- all in one:
  - func Model(matrix [][]string) *S
    as ItemS, OptaS
- one by one

- Items may be added as long as:
  - there are not options
  - Prim has not been set to another value (? - not practical)
-

+ SetUp
- type SetUp struct with prim pointer usf
- type Setting func(* S) Setting

