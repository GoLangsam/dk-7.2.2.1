// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package x

// ===========================================================================

// Dict
type Dict map[string]Index

// ===========================================================================

// LearnOnce registers some id and its index,
// and panics iff the id is already known.
func (a Dict) LearnOnce(name string, index Index) Dict {
	if i, ok := a[name]; ok {
		_ = i // TODO: show data: name, i, index
		panic("duplicate name encountered.")
	}

	a[name] = index
	return a
}

// MustKnow
func (a Dict) MustKnow(name string) Index {
	i, ok := a[name]
	if !ok {
		panic("unknown name.")
	} // TODO: show data: name
	return i
}

// ===========================================================================
