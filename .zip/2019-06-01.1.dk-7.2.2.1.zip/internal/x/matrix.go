// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package x

// ===========================================================================

// M represents the (usually sparse) matrix of some exact cover problem.
//
// Note: The null value is NOT useful! Use `NewMatrix(...)`.
type M struct {
	Names // the names
	Items // the items
	Optas // the options
}

// NewMatrix returns (a pointer to) a new (sparse) matrix M
// initialized with given capacity cap.
func NewMatrix(cap int, dict *Dict) *M {
	m := M{
		Names{make([]Name, 0, cap), dict},
		Items{make([]Item, 0, cap), dict},
		Optas{make([]Opta, 0, cap*cap), dict}, // pre-allocate generously; subsequent Clone will cut the fat
	}
	return &m
}

// ===========================================================================

// Clone returns a new matrix consisting of a copy of the slice data of a.
//
// Note: The name-dictionary is read-only!
// Only its pointer is copied.
func (a *M) Clone() *M {
	m := M{
		Names{a.NameS.Clone(), a.Names.Dict},
		Items{a.ItemS.Clone(), a.Items.Dict},
		Optas{a.OptaS.Clone(), a.Optas.Dict},
	}

	return &m
}

// ===========================================================================

func (a *M) LearnItemName(name string, at Index) *M {
	a.Names.Dict.LearnOnce(name, at)
	a.NameS = a.NameS.AppendName(name)

	return a
}

func (a *M) AddList(name string, root Index) *M {

	a.LearnItemName(name, root)
	a.ItemS = a.ItemS.AppendList(root)
	a.OptaS = a.OptaS.AppendNull()

	return a
}

// AddItem appends a named item to the itemlist rooted at root.
func (a *M) AddItem(name string, root Index) *M {

	a.LearnItemName(name, len(a.ItemS))
	a.ItemS = a.ItemS.AppendItem(root)
	a.OptaS = a.OptaS.AppendRoot(root)

	return a
}

// AddMark appends a spacer. The mark must be < 0.
func (a *M) AddMark(mark, prev Index) *M {

	a.OptaS = a.OptaS.AppendMark(mark, prev)

	return a
}
