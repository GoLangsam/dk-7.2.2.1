// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// xc implements the excat cover via dancing links
package xc

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// ===========================================================================

// P represents a problem under construction.
//
// Note: The null value is NOT useful!
type P struct {
	x.Dict
	*x.M // (a pointer to) the matrix.
}

// Items returns a new problem matrix
// populateded with the given primary items and
// ready to accept secondary items (if any) and options.
//
// It panics iff some duplicate item name is encountered,
// or iff some item has an empty string as its name.
func Items(items ...string) *P {
	N := len(items)
	if N < 1 {
		panic("need one Item at least.")
	}

	cap := N + 2                                // allocate two more: for primary and secondary roots
	a := P{Dict: make(map[string]x.Index, cap)} // make new problem with its dictionary
	a.M = x.NewMatrix(cap, &a.Dict)             // make the matrix

	return a.AddItems(items...)
}

// AddItems returns the extended problem - thus calls may be chained.
//
// Panics iff AddOptions had been called before (with non-empty args).
func (a *P) AddItems(items ...string) *P {
	if len(items) == 0 {
		return a
	}

	if len(a.ItemS) != len(a.OptaS) {
		panic("Cannot add any more items: options have been added already!")
	}

	root := len(a.NameS)  // here the root will be.
	var name string       // empty name for main root. TODO: will panic on 2nd call!
	a.AddList(name, root) // add it to the matrix

	// push things in lockstep
	for _, name = range items {
		a.AddItem(name, root)
	}

	return a
}

// AddOption returns the extended problem - thus calls may be chained.
func (a *P) AddOption(items ...string) *P {
	if len(items) == 0 {
		return a
	}

	if len(a.ItemS) == len(a.OptaS) { // add trailing spacer
		a.AddMark(-1, 0) // Note: DK starts marking with 0, and decrements. We start negative, using -1.
	}

	c := len(a.OptaS)                        // shall create a.OptaS[c]
	a.OptaS[c-1].Next = (c - 1) + len(items) // update preceeding spacer

	for _, name := range items {
		a.OptaS = a.OptaS.AppendOpta(a.MustKnow(name)) // append to Column(name-Index)
	}

	a.AddMark(a.OptaS[c-1].Root-1, c) // add trailing spacer

	return a

}

// Matrix returns (a clone of) the matrix.
func (a *P) Matrix() *x.M {
	return a.M.Clone()
}

// S returns an instance searchable for solutions - ready to dance.
//
// Note: each result obtained is a fresh clone - safe for concurrent use by another go routine.
func (a *P) S(items ...string) *S {
	cap := a.OptaS[0].Root // allocate worst case size - hope this makes Tom more happy :-)

	s := S{
		a.M.Clone(),
		make([]int, 0, cap),
	}
	return &s
}

// ===========================================================================

// S represents a problem under investigation: searching for solutions.
//
// Note: The null value is NOT useful!
type S struct {
	*x.M   // (a pointer to) the matrix.
	x.LiFo // the search path to solution.
	// TODO: add counters: global and per-level
	// TODO: add functionpointers for non-default handling: tick, search col, filterfn for search, ...
	// TODO: implement dance & co.
}

// Matrix returns (a clone of) the matrix.
func (a S) Matrix() *x.M {
	return a.M.Clone()
}

// ===========================================================================
