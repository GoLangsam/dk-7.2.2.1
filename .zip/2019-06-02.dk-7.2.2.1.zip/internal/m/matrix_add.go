// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package m

// ===========================================================================

func (a *M) addName(name string, at int) *M {
	a.Names.Dict.LearnOnce(name, at)
	a.NameS = a.AppendName(name)

	return a
}

// AddList appends a root for a new itemlist rooted at root.
func (a *M) addList(name string, root int) *M {

	if len(a.NameS) == 0 { // only for first root
		a.addName(name, root)
	}
	a.ItemRootS = append(a.ItemRootS, root)
	a.ItemS = a.AppendList(root)
	a.OptaS = a.AppendNull()

	return a
}

// AddItem appends a named item to the itemlist rooted at root.
func (a *M) addItem(name string, root int) *M {

	a.addName(name, len(a.ItemS))

	a.ItemS = a.AppendItem(root)
	a.OptaS = a.AppendRoot(root)

	return a
}

// AddMark appends a spacer. The mark must be < 0.
func (a *M) addMark(mark, prev int) *M {

	a.OptaRootS = append(a.OptaRootS, len(a.OptaS))
	a.OptaS = a.AppendMark(mark, prev)

	return a
}

// AddCell appends a cell to the (vertical) list rooted at root.
func (a *M) addCell(root int) *M {

	a.OptaS = a.AppendOpta(root)

	return a
}

// ===========================================================================
