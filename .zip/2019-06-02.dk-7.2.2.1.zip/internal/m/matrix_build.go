// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package m

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// ===========================================================================

// AddItems returns the extended problem - thus calls may be chained.
//
// Panics iff AddOptions had been called before (with non-empty args).
func (a *M) AddItems(items ...string) *M {
	if len(items) == 0 {
		return a
	}

	if len(a.ItemS) != len(a.OptaS) {
		panic("Cannot add any more items: options have been added already!")
	}

	root := len(a.NameS)  // here the root will be.
	var name string       // empty name for main root.
	a.addList(name, root) // add it to the matrix

	// push things in lockstep
	for _, name = range items {
		a.addItem(name, root)
	}

	return a
}

// AddOption returns the extended problem - thus calls may be chained.
func (a *M) AddOption(items ...string) *M {
	if len(items) == 0 {
		return a
	}

	if len(a.ItemS) == len(a.OptaS) { // add first trailing spacer
		a.addMark(-1, 0) // Note: DK starts marking with 0, and decrements. We start negative, using -1.
	}

	var dict x.Dict = make(map[string]x.Index, len(items)) // to avoid duplicate items in this option.

	c := len(a.OptaS)                        // shall create a.OptaS[c]
	a.OptaS[c-1].Next = (c - 1) + len(items) // update preceeding spacer

	for i, name := range items {
		dict.LearnOnce(name, i)     // panics on duplicate name
		a.addCell(a.MustKnow(name)) // append to Column(name-Index)
	}

	a.addMark(a.OptaS[c-1].Root-1, c) // add trailing spacer

	return a
}

// ===========================================================================
