// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package m

// ===========================================================================

type Do struct {
	*M
	Do func(int)
}

func (a *M) Do(f func(int)) Do {
	return Do{a, f}

}

// ===========================================================================

// ForEachNext.
func (a *Do) ForEachNext(root int) {

	for curr := a.ItemS[root].Next; curr != root; curr = a.ItemS[curr].Next {
		a.Do(curr)
	}
}

// ForEachPrev.
func (a *Do) ForEachPrev(root int) {

	for curr := a.ItemS[root].Prev; curr != root; curr = a.ItemS[curr].Prev {
		a.Do(curr)
	}
}

// ===========================================================================

// ForEachOptaNext.
func (a *Do) ForEachOptaNext(root int) {

	for curr := a.OptaS[root].Next; curr != root; curr = a.OptaS[curr].Next {
		a.Do(curr)
	}
}

// ForEachOptaPrev.
func (a *Do) ForEachOptaPrev(root int) {

	for curr := a.OptaS[root].Prev; curr != root; curr = a.OptaS[curr].Prev {
		a.Do(curr)
	}
}

// ForEachNextWrong.
func (a *Do) ForEachNextWrong(i int) {

	root := a.OptaS[i].Root
	curr := a.OptaS[i].Next

	for curr != i {
		if curr == root {
			curr = a.OptaS[curr].Next
			continue
		}
		a.Do(curr)
	}
}

// ForEachOtherNext.
func (a *Do) ForEachOtherNext(i int) {

	if a.OptaS[i].Root < 0 { // Spacer
		panic("OptaS.ForEachOtherNext must not be used on a spacer!")
	}

	for curr := i + 1; curr != i; {
		if a.OptaS[curr].Root < 0 { // Spacer
			curr = a.OptaS[curr].Prev
			continue
		}
		a.Do(curr)
		curr++
	}
}

// ===========================================================================
