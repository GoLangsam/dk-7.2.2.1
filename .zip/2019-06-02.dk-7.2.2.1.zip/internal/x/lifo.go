// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package x

// ===========================================================================

// LiFo represents a last-in first-out buffer for indices.
type LiFo []Index

// Note: some people use a stack

// ===========================================================================

// Clone returns a copy of a given LiFo.
//
// Thus, the returned value is safe for concurrent use.
func (a LiFo) Clone() LiFo {
	c := make([]Index, len(a))
	copy(c, a)
	return c
}

// ===========================================================================

// Push index i.
func (a LiFo) Push(i Index) LiFo {
	return append(a, i)
}

// Drop forgets the most recently pushed index.
func (a LiFo) Drop() LiFo {
	return a[:len(a)-1]
}

// Peek returns the current LiFo.
//
// The result is intended for quick checks only,
// must NOT be modified
// and is NOT safe for concurrent use!
func (a LiFo) Peek() LiFo {
	return a
}

// ===========================================================================
