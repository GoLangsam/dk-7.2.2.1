// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// xc implements the excat cover via dancing links
package xc

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/m"
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// ===========================================================================

// P represents a problem under construction.
//
// Note: The null value is NOT useful!
type P struct {
	*m.M // (a pointer to) the matrix.
}

// ===========================================================================

// Problem returns a new problem matrix
// populated with the given lines.
//
// Options (if any) must be preceded by an empty line.
//
// The first line defines the primary items,
// subsquent non-empty lines (if any) define (groups of) secondary items.
//
// The problem is ready to accept secondary items (if any)
// and further options
// by subsequent calls to its methods AddItems(...) resp. AddOption(...).
//
// It panics iff some duplicate item name is encountered,
// or iff some item has an empty string as its name
// or iff some option refers to an item name more than once
// or iff there are no items.
func Problem(lines ...[]string) *P {
	var cap int

	for _, line := range lines {
		size := len(line)
		if size == 0 {
			break
		}
		cap += size + 1 // one more for root
	}

	if cap == 0 {
		panic("Problem: need some items!")
	}

	a := P{m.NewMatrix(cap)} // make new problem matrix

	var isOption bool
	for _, line := range lines {
		if len(line) == 0 {
			isOption = true
			continue
		}

		if isOption {
			a.AddOption(line...)
		} else {
			a.AddItems(line...)
		}

	}

	return &a
}

// ===========================================================================

// Items returns a new problem matrix
// populated with the given primary items and
// ready to accept secondary items (if any) and options.
//
// It panics iff some duplicate item name is encountered,
// or iff some item has an empty string as its name.
func Items(items ...string) *P {
	N := len(items)
	if N < 1 {
		panic("Items: need one item - at least!")
	}

	cap := N + 2             // allocate two more: for primary and secondary roots
	a := P{m.NewMatrix(cap)} // make new problem matrix

	a.AddItems(items...)

	return &a
}

// Matrix returns (a clone of) the matrix.
func (a *P) Matrix() *m.M {
	return a.M.Clone()
}

// S returns an instance searchable for solutions - ready to dance.
//
// Note: each result obtained is a fresh clone - safe for concurrent use by another go routine.
func (a *P) S(items ...string) *S {
	cap := a.OptaS[0].Root // allocate worst case size - hope this makes Tom more happy :-)

	s := S{
		a.M.Clone(),
		make([]int, 0, cap),
	}
	return &s
}

// ===========================================================================

// S represents a problem under investigation: searching for solutions.
//
// Note: The null value is NOT useful!
type S struct {
	*m.M   // (a pointer to) the matrix.
	x.LiFo // the search path to solution.
	// TODO: add counters: global and per-level
	// TODO: add functionpointers for non-default handling: tick, search col, filterfn for search, ...
	// TODO: implement dance & co.
}

// Matrix returns (a clone of) the matrix.
func (a S) Matrix() *m.M {
	return a.M.Clone()
}

// ===========================================================================
