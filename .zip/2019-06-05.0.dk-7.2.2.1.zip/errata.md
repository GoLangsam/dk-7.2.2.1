
P 125: I2: there were no secondary items => there were no _primary_ items