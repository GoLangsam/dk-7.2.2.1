// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// drum.go provides a simple counter (with names based on musical methaphores)

package pace

import (
	"fmt"
	"sort"
	//	"sync"
)

type counter map[int]int64

// drum is named counter
type drum struct {
	Nam     string
	Cnt     int64
	Map     counter
	verbose bool
	//	sync.Mutex
}

// newDrum returns a new initialized drum.
func newDrum(nam string, cap int) drum {
	return drum{
		Nam: nam,
		Map: make(map[int]int64, cap),
	}
}

// Beat increments b.Cnt by one.
// And iff b.verbose then b.Map[cur] get incremented as well.
func (b *drum) Beat(cur int) {
	//	b.Lock()
	//	defer b.Unlock()
	b.Cnt++
	if b.verbose {
		b.Map[cur]++
	}
}

// Sort returns the keys of b.Map in a sorted slice
func (b *drum) Sort() []int {
	//	b.Lock()
	//	defer b.Unlock()
	var keys sort.IntSlice
	for key := range b.Map {
		keys = append(keys, key)
	}
	keys.Sort() // Note: see also sort.Ints( []int )
	return keys
}

// Print prints a drum, if it's not empty, as lines of tab-terminated cells.
// And iff b.verbose then b.Map is printed in ascending order of its keys.
func (b *drum) Print() {
	//	b.Lock()
	//	defer b.Unlock()
	if b.Cnt < 1 { // do not print empty counter
		return
	}
	fmt.Printf("%s\t% 9d\t"+"\n", b.Nam, b.Cnt)
	if b.verbose {
		for _, key := range b.Sort() {
			fmt.Printf("%6d\t% 9d\t"+"\n", key, b.Map[key])
		}
	}
}
