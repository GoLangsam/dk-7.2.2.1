// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pace

import (
	"fmt"

	"github.com/GoLangsam/dk-7.2.2.1/internal/d" // dancing
	"github.com/GoLangsam/dk-7.2.2.1/internal/m" // problem matrix
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// Dancer can Dance(int) (and may have other implementations as well)
type Dancer interface {
	Dance(int)            // the default dance function
	SetOnNext(func())     // the Callback - mandatory - should be called to start searching!
	SetOnLeaf(func(int))  // optional: Update-Counting
	GetOnNext() func()    // the Callback - mandatory - should be called to start searching!
	GetOnLeaf() func(int) // optional: Update-Counting
	Peek() []int          // current options folded away
}

// turn is what a dancer during a dance does and does and does.
type turn struct {
	OnLeaf func() bool        // YES We have to abort
	OnGoal func() bool        // YES We have a solution
	OnFail func() (int, bool) // YES We have to go on dancing & goaling - may be
	Dance  func(int)          // and We have to dance here now

	verbose bool
}

// Pace is what dancer loves to follow.
type Pace struct {
	*m.M

	*d.D

	x.LiFo

	turn

	drums

	Level int

	verboseOnSpin bool
	verboseOnLeaf bool
	verboseOnGoal bool
	verboseOnFail bool
}

// ========================================================

// InitialDepth of space allocation for stack and drum
// var InitialDepth = 100

// New returns (a pointer to) a fresh Pace
// with silent default settings, ready to be formed.
func New(M *m.M, D *d.D) *Pace {

	{
		var dCheckInterface Dancer = D
		_ = dCheckInterface
	}

	cap := len(M.ItemS)

	a := new(Pace)

	a.M = M
	a.D = D
	a.LiFo = make([]int, 0, cap)

	a.turn.Dance = a.D.Dance
	a.turn.OnGoal = a.onGoal // YES We have a solution
	a.turn.OnFail = a.onFail // YES We have to go on dancing & goaling
	a.turn.OnLeaf = a.onLeaf // YES We have to abort

	a.drums = newDrums(cap)

	a.D.SetOnLeaf(a.drums.leaf.Beat)
	a.D.SetOnNext(a.Spin)

	return a
}

// ========================================================

// Dance starts dancing the paced dance.
func (a *Pace) Dance() *Pace {
	a.D.GetOnNext()()
	return a
}

// ========================================================

func (a *Pace) Print() *Pace {
	a.drums.Print()
	return a
}

// ========================================================

// Default methods

func (a *Pace) onLeaf() bool { // Do we have to abort?
	if a.verboseOnLeaf {
		// TODO: What to print?
		// d.Stacker.Top().PrintValue("Stack-Top")
		// l.PrintValue()
		// l.PrintAways()
	}
	return false
}

// ========================================================

func (a *Pace) onGoal() bool { // Do we have a solution?
	if a.D.ItemS[0].Next == 0 { // YES We have a solution
		if a.verboseOnGoal {
			// TODO: d.PrintGoal()
		} // ... we may show it
		return true
	}

	return false
}

// ========================================================

func (a *Pace) onFail() (here int, found bool) {

	Size := len(a.OptaS) // cannot be that large

	for curr := a.D.ItemS[0].Next; curr != 0; curr = a.D.ItemS[curr].Next {
		size := a.D.OptaS[curr].Root
		// TODO: the "non-sharp/sharp preference"-Heuristics
		// if a.NameS[curr] does/doesn't start with `#` {
		//	size = size + len(a.Optas.MarkS) - 1 // #-of-options
		// }
		if size == 0 {
			here, found = -1, false
			break
		}
		if size < Size {
			Size = size
			here = curr
			found = true
		}
	}
	if a.verboseOnFail {
		fmt.Println("onFail found:\t", here, "\t", found, "\t")
	}
	return
}
