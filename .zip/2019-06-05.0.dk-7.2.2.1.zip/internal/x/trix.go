// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package x

// ===========================================================================

// Trix is a highly compact representation of an exact cover problem matrix.
type Trix struct {
	ItemS
	OptaS
}

// ===========================================================================

// Clone returns a new structure consisting of a copy of the data of a.
func (a Trix) Clone() Trix {
	return Trix{
		a.ItemS.Clone(),
		a.OptaS.Clone(),
	}
}

// ===========================================================================
