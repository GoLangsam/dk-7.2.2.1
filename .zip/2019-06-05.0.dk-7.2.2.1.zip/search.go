// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package xc

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/d" // dance
	"github.com/GoLangsam/dk-7.2.2.1/internal/m" // problem matrix
	"github.com/GoLangsam/dk-7.2.2.1/internal/s" // pace
)

func Search(M *m.M) {
	D := d.D{
		ItemS: M.ItemS.Clone(),
		OptaS: M.OptaS.Clone(),
		LiFo:  make([]int, 0, len(M.ItemS)),
	} // can Dance - implements pace.Dancer

	var v, vg, rh, vd, vb, vc bool // as in tees/cmd/NQueensR
	_, _ = vb, rh // d.Dancer = dancing.New(vb, rh, false)
	// pace.VerboseTurn(vt) // vt not defined,
	var vs, vt bool // TODO: support in cmd/NQueensR
	vc = true
	vd = true
	a, _ := pace.New(M, &D).
		Form(
			pace.VerbosePaceOnSpin(vs),
			pace.VerbosePaceOnLeaf(v),
			pace.VerbosePaceOnGoal(vg),
			pace.VerbosePaceOnFail(vc),
			pace.VerboseTurn(vt),
			pace.VerboseDrums(vd),
			pace.VerboseDrumsGoal(vd),
			pace.VerboseDrumsFail(vd),
			pace.VerboseDrumsCall(vd),
			pace.VerboseDrumsLeaf(vd),
		)

	a.Dance().Print()
}
