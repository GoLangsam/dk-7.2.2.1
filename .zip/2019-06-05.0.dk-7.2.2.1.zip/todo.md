
- create secondary items on demand! (Iff we HAVE primary items!)
- make sure, any option contains one primary item (at least)! (Iff we HAVE primary items!)

- TODO: the "non-sharp/sharp preference"-Heuristics

- TODO: "container/.../drum" - remove, or improve
- TODO: "tees/dance/dancers/drummer/drum" - remove, or improve

- TODO: "container/.../stack" - remove verbose.go
- TODO: "tees/dance/..." - remove verbose.go whereever possible


Pacer:
*m.M
*d.D implements d.Dance(int) as default, (and other f(int), may be...)
Turner
