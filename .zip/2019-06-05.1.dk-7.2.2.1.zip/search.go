// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package xc

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/m" // problem matrix
	"github.com/GoLangsam/dk-7.2.2.1/internal/s" // pace
)

func Search(M *m.M) {
	var v, vg, rh, vd, vb, vc bool // as in tees/cmd/NQueensR
	_, _ = vb, rh                  // d.Dancer = dancing.New(vb, rh, false)
	// pace.VerboseTurn(vt) // vt not defined,
	var vs, vt bool // TODO: support in cmd/NQueensR
	// vc = true
	vd = true
	a, _ := s.New(M).
		Form(
			s.VerbosePaceOnSpin(vs),
			s.VerbosePaceOnLeaf(v),
			s.VerbosePaceOnGoal(vg),
			s.VerbosePaceOnFail(vc),
			s.VerboseTurn(vt),
			s.VerboseDrums(vd),
			s.VerboseDrumsGoal(vd),
			s.VerboseDrumsFail(vd),
			s.VerboseDrumsCall(vd),
			s.VerboseDrumsLeaf(vd),
		)

	a.Search().Print()
}
