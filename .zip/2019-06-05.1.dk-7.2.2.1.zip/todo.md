
- TODO: doc.go for each package: x s m d (& l)
  - including TODOs - for liteIDE :-)

- m TODO: create secondary items on demand! (Iff we HAVE primary items!)
- m TODO: make sure, any option contains one primary item (at least)! (Iff we HAVE primary items!)

- s TODO: TODO: the "non-sharp/sharp preference"-Heuristics: Idea: a Name-Filter-Func

- s TODO: more Setters for Search

- container TODO: "container/.../drum" - remove, or improve
- container TODO: "container/.../stack" - remove verbose.go

- tees TODO: "tees/dance/dancers/drummer/drum" - remove, or improve
- tees TODO: "tees/dance/..." - remove verbose.go whereever possible
