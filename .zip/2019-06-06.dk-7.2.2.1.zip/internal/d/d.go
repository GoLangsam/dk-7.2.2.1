// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/m"
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// ===========================================================================

type D struct {
	x.ItemS
	x.OptaS
	x.LiFo // TODO: better place; or direct!

	onNext func()    // callback
	onLeaf func(int) // optional:
}

func New(M *m.M) *D {
	return &D{
		ItemS: M.ItemS.Clone(),
		OptaS: M.OptaS.Clone(),
		LiFo:  make([]int, 0, len(M.ItemS)),
	} // can Dance - implements s.Dancer
}

// ===========================================================================

// Implement s.Dancer

func (a *D) SetOnLeaf(f func(int)) {
	a.onLeaf = f
}

func (a *D) SetOnNext(f func()) {
	a.onNext = f
}

func (a *D) GetOnLeaf() func(int) {
	return a.onLeaf
}

func (a *D) GetOnNext() func() {
	return a.onNext
}

// ===========================================================================

func (a *D) DanceFake(here int) {
	a.ItemS.DeTach(here)
	a.LiFo = a.LiFo.Push(here)
	if a.onLeaf != nil {
		a.onLeaf(len(a.LiFo))
	}
	a.onNext()
	a.LiFo = a.LiFo.Drop()
	a.ItemS.ReTach(here)
}

// ===========================================================================
