// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package m

// ===========================================================================

func (a *M) addName(name string, at int) {
	a.Names.Dict.LearnOnce(name, at)
	a.Names.NameS = a.Names.NameS.AppendName(name)
}

// AddList appends a root for a new itemlist rooted at root.
func (a *M) addList(name string, root int) {

	if len(a.NameS) == 0 { // only for first root
		a.addName(name, root)
	}

	a.Items.MarkS = a.Items.MarkS.AppendMark(root)
	a.Items.ItemS = a.Items.ItemS.AppendList(root)

	a.Optas.OptaS = a.Optas.OptaS.AppendNull() // keep optas in sync
}

// AddItem appends a named item to the itemlist rooted at root.
func (a *M) addItem(name string, root int) {

	{
		a.addName(name, len(a.ItemS))
	}

	a.Items.ItemS = a.Items.ItemS.AppendItem(root)
	a.Optas.OptaS = a.Optas.OptaS.AppendRoot(root)
}

// AddMark appends a spacer. The mark must be < 0.
func (a *M) addMark(mark, prev int) {

	a.Optas.MarkS = a.Optas.MarkS.AppendMark(len(a.OptaS))
	a.Optas.OptaS = a.Optas.OptaS.AppendMark(mark, prev)
}

// AddCell appends a cell to the (vertical) list rooted at root.
func (a *M) addCell(root int) {

	a.Optas.OptaS = a.Optas.OptaS.AppendOpta(root)
}

// ===========================================================================
