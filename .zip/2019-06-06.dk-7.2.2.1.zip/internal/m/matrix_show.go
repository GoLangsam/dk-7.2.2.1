// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package m

import (
	"fmt"
)

// ===========================================================================

// ShowOption exercice 12
func (a *M) ShowOption(x int) {

	if x <= len(a.ItemS) {
		panic("ShowOption: used on an item!")
	}

	if x > len(a.OptaS) {
		panic("ShowOption: index too large - no option here!")
	}

	if a.OptaS[x].Root < 0 { // Spacer
		panic("ShowOption: used on a spacer!")
	}

	show := func(i int) {
		fmt.Print(a.NameS[a.OptaS[i].Root], "\t")
	}

	a.Do(show).ForEachLineNext(x)

	i := a.OptaS[x].Root
	q := a.OptaS[i].Next

	var k int
	for k = 1; q != x && q != i; k++ {
		q = a.OptaS[q].Next
	}

	name := a.NameS[a.OptaS[x].Root]
	if q != i {
		fmt.Print("the option containing", name, " is ", k, " of ", a.OptaS[i].Root, "\t")
	} else {
		fmt.Print("the option containing", name, " is not on this list", "\t")
	}
	fmt.Println()
}

// ===========================================================================
