// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

// "github.com/GoLangsam/container/oneway/drum" // == "github.com/GoLangsam/tees/dance/dancers/drummer/drum"

// drums consolidates all drums (counters) needed.
type drums struct {
	goal drum // Niveaus counts dances per level
	fail drum // Deadend counts fail ends per level
	call drum // Grooves counts solutions per length
	leaf drum // UpDates counts unLink per level
	// Note: No drum for Push & Pop, as these occur in sync with Call

	verbose bool
}

// newDrums provides a fresh ensemble of drums
func newDrums(cap int) drums {
	return drums{
		goal: newDrum("Grooves", cap),
		fail: newDrum("Deadend", cap),
		call: newDrum("Niveaus", cap),
		leaf: newDrum("UpDates", cap),
	}
}

// Print has all drums print iff Verbose
func (d *drums) Print() {
	if d.verbose {
		d.goal.Print()
		d.fail.Print()
		d.call.Print()
		d.leaf.Print()
	}
}
