// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

import (
	"fmt"

	"github.com/GoLangsam/dk-7.2.2.1/internal/d" // dancing
	"github.com/GoLangsam/dk-7.2.2.1/internal/m" // problem matrix
)

// ========================================================

// Searcher consolidates what's needed to Search.
type Searcher struct {
	m    *m.M // the problem Matrix - intentionally shadowed
	*d.D      // the Dancer - can Dance
	pace      // the Pacer  - can Spin or Turn

	// x.LiFo

}

// ========================================================

// New returns (a pointer to) a fresh Searcher
// with silent default settings,
// ready to be formed, and
// ready to Search().
func New(M *m.M) *Searcher {

	cap := len(M.ItemS)

	a := new(Searcher)
	a.m = M
	a.D = d.New(M) // can Dance - implements Dancer

	// a.LiFo = make([]int, 0, cap)

	a.pace.turn.Dance = a.D.Dance
	a.pace.turn.OnGoal = a.onGoal // YES We have a solution
	a.pace.turn.OnFail = a.onFail // YES We have to go on dancing & goaling
	a.pace.turn.OnLeaf = a.onLeaf // YES We have to abort

	a.pace.drums = newDrums(cap)

	a.SetOnLeaf(a.pace.drums.leaf.Beat)
	a.SetOnNext(a.pace.Spin)

	return a
}

// ========================================================

// Search is what a Searcher is busy doing.
func (a *Searcher) Search() *Searcher {
	a.D.GetOnNext()()
	return a
}

// ========================================================

// Print prints results of a Search
// depending on the verbosity settings.
//
// Per default: nothing is printed.
func (a *Searcher) Print() *Searcher {
	a.pace.drums.Print()
	return a
}

// ========================================================

// Default methods

func (a *Searcher) onLeaf() bool { // Do we have to abort?
	if a.pace.verboseOnLeaf {
		// TODO: What to print?
		// d.Stacker.Top().PrintValue("Stack-Top")
		// l.PrintValue()
		// l.PrintAways()
	}
	return false
}

// ========================================================

func (a *Searcher) onGoal() bool { // Do we have a solution?
	if a.ItemS[0].Next == 0 { // YES We have a solution
		if a.pace.verboseOnGoal {
			for _, opta := range a.LiFo {
				show := func(i int) { fmt.Print(a.m.NameS[a.OptaS[i].Root]) }
				// show(opta)
				// a.m.Do(show).ForEachOtherNext(opta)
				a.m.Do(show).ForEachLineNext(opta)
				fmt.Println()
			}
		} // ... we may show it
		return true
	}

	return false
}

// ========================================================

// onFail searches the next item to be considered (if any).
// It implements the MRV heuristic.
func (a *Searcher) onFail() (here int, found bool) {

	Size := len(a.OptaS) // cannot be that large

	for curr := a.ItemS[0].Next; curr != 0; curr = a.ItemS[curr].Next {
		size := a.OptaS[curr].Root
		// TODO: the "non-sharp/sharp preference"-Heuristics
		// if a.NameS[curr] does/doesn't start with `#` {
		//	size = size + len(a.Optas.MarkS) - 1 // #-of-options
		// }
		if size == 0 {
			here, found = -1, false
			break
		}
		if size < Size {
			Size = size
			here = curr
			found = true
		}
	}
	if a.pace.verboseOnFail {
		fmt.Println("onFail found:\t", here, "\t", found, "\t")
	}
	return
}

// ========================================================
