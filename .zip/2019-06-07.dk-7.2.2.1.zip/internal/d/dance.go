// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

// ===========================================================================

func (a *D) Dance(i int) {

	var p, j int

	a.deTachItem(i)

	for x := a.OptaS[i].Next; x != i; x = a.OptaS[x].Next {

		a.LiFo = a.LiFo.Push(x)

		p = x + 1
		for p != x {
			j = a.OptaS[p].Root
			if j < 0 { // Spacer
				p = a.OptaS[p].Prev
				continue
			}
			a.deTachItem(j)
			p++
		}

		a.onNext()

		p = x - 1
		for p != x {
			j = a.OptaS[p].Root
			if j < 0 { // Spacer
				p = a.OptaS[p].Next
				continue
			}
			a.reTachItem(j)
			p--
		}

		a.LiFo = a.LiFo.Drop()

	}
	a.reTachItem(i)
}

// ===========================================================================

func (a *D) deTachItem(i int) {

	for p := a.OptaS[i].Next; p != i; p = a.OptaS[p].Next {
		a.deTach(p)
	}

	//  a.ItemS.DeTach(i)
	l := a.ItemS[i].Prev
	r := a.ItemS[i].Next
	a.ItemS[l].Next = r
	a.ItemS[r].Prev = l
}

func (a *D) reTachItem(i int) {

	//  a.ItemS.ReTach(i)
	l := a.ItemS[i].Prev
	r := a.ItemS[i].Next
	a.ItemS[l].Next = i
	a.ItemS[r].Prev = i

	for p := a.OptaS[i].Prev; p != i; p = a.OptaS[p].Prev {
		a.reTach(p)
	}
}

// ===========================================================================

// deTach hides p.
func (a *D) deTach(p int) {
	q := p + 1

	var x, u, d int
	for q != p { // ForEachOtherNext
		x = a.OptaS[q].Root
		u = a.OptaS[q].Prev
		d = a.OptaS[q].Next

		if x < 0 { // Spacer
			q = u
			continue
		}
		//  a.OptaS.DeTach(q)
		a.OptaS[u].Next = d
		a.OptaS[d].Prev = u
		a.OptaS[x].Root--
		q++

		if a.onLeaf != nil { // count update
			a.onLeaf(len(a.LiFo))
		}
	}
}

// reTach unhides p.
func (a *D) reTach(p int) {
	q := p - 1

	var x, u, d int
	for q != p { // ForEachOtherPrev
		x = a.OptaS[q].Root
		u = a.OptaS[q].Prev
		d = a.OptaS[q].Next

		if x < 0 { // Spacer
			q = d
			continue
		}
		//  a.OptaS.ReTach(q)
		a.OptaS[u].Next = q
		a.OptaS[d].Prev = q
		a.OptaS[x].Root++
		q--
	}
}

// ===========================================================================
