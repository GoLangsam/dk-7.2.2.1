// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

// VerboseDrums returns a function which
// sets pace.drums.verbose to v
// and returns it's undo doFn.
func VerboseDrums(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.drums.verbose
		a.pace.drums.verbose = v
		return func() doFn {
			return VerboseDrums(prev)(a)
		}
	}
}

// VerboseDrumsGoal returns a function which
// sets pace.drums.goal.verbose to v
// and returns it's undo doFn.
func VerboseDrumsGoal(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.drums.goal.Verbose
		a.pace.drums.goal.Verbose = v
		return func() doFn {
			return VerboseDrumsGoal(prev)(a)
		}
	}
}

// VerboseDrumsFail returns a function which
// sets pace.drums.fail.verbose to v
// and returns it's undo doFn.
func VerboseDrumsFail(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.drums.fail.Verbose
		a.pace.drums.fail.Verbose = v
		return func() doFn {
			return VerboseDrumsFail(prev)(a)
		}
	}
}

// VerboseDrumsCall returns a function which
// sets pace.drums.call.verbose to v
// and returns it's undo doFn.
func VerboseDrumsCall(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.drums.call.Verbose
		a.pace.drums.call.Verbose = v
		return func() doFn {
			return VerboseDrumsCall(prev)(a)
		}
	}
}

// VerboseDrumsLeaf returns a function which
// sets pace.drums.leaf.verbose to v
// and returns it's undo doFn.
func VerboseDrumsLeaf(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.drums.leaf.Verbose
		a.pace.drums.leaf.Verbose = v
		return func() doFn {
			return VerboseDrumsLeaf(prev)(a)
		}
	}
}
