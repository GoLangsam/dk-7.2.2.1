// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

// Dancer can Dance(int) (and may have other implementations as well)
//
// s.New(M) internally creates a concrete instance
// which must satisfy this interface
// in order to allow defaulting
// and external settings.
type Dancer interface {
	Dance(int)            // the default dance function
	SetOnNext(func())     // set the Callback - mandatory
	SetOnLeaf(func(int))  // set the Update-Counting (optional)
	GetOnNext() func()    // get the Callback - called on Search!
	GetOnLeaf() func(int) // get the Update-Counting (optional)
	// Peek() []int          // current options folded away (read-only!)
}

// pace is what dancer loves to follow.
type pace struct {
	turn
	drums
	level int

	verboseOnSpin bool
	verboseOnLeaf bool
	verboseOnGoal bool
	verboseOnFail bool
}

// ========================================================
