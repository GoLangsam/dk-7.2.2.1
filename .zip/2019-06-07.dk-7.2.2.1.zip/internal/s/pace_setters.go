// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

// VerbosePaceOnSpin returns a function which
// sets pace.verboseOnSpin to v
// and returns it's undo doFn.
func VerbosePaceOnSpin(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.verboseOnSpin
		a.pace.verboseOnSpin = v
		return func() doFn {
			return VerbosePaceOnSpin(prev)(a)
		}
	}
}

// VerbosePaceOnLeaf returns a function which
// sets pace.verboseOnLeaf to v
// and returns it's undo doFn.
func VerbosePaceOnLeaf(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.verboseOnLeaf
		a.pace.verboseOnLeaf = v
		return func() doFn {
			return VerbosePaceOnLeaf(prev)(a)
		}
	}
}

// VerbosePaceOnGoal returns a function which
// sets pace.verboseOnGoal to v
// and returns it's undo doFn.
func VerbosePaceOnGoal(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.verboseOnGoal
		a.pace.verboseOnGoal = v
		return func() doFn {
			return VerbosePaceOnGoal(prev)(a)
		}
	}
}

// VerbosePaceOnFail returns a function which
// sets pace.verboseOnFail to v
// and returns it's undo doFn.
func VerbosePaceOnFail(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.verboseOnFail
		a.pace.verboseOnFail = v
		return func() doFn {
			return VerbosePaceOnFail(prev)(a)
		}
	}
}
