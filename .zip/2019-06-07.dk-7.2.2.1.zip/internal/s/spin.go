// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

// ========================================================

// CallBacks from Dance - as OnNext

// Spin is what keeps a dancer to turn to dance dancing or not
func (d *pace) Spin() {

	if d.turn.OnLeaf != nil && d.turn.OnLeaf() {return}       // YES We have to abort

	if d.turn.OnGoal != nil && d.turn.OnGoal() {              // YES We have a solution
		if d.verboseOnSpin { d.drums.goal.Beat(d.level) } // ... we count our happyness
		return // and return
	}

	next, ok := d.turn.OnFail() // ... keep going?

	if !ok { // YES We have a failure/dead-end
		if d.verboseOnSpin { d.drums.fail.Beat(d.level) } // ... we count our suffering
		return // and return

	} else { // YES We have to go on goaling
		if d.verboseOnSpin { d.drums.call.Beat(d.level) } // ... we count our effort
	}

	d.level++
	d.turn.Dance(next)
	d.level--
}

// SpinBeatless keeps a dancer turning to dance dancing or not - but without beating
func (d *turn) SpinBeatless() {

	if d.OnLeaf != nil && d.OnLeaf() { return } // YES We have to abort
	if d.OnGoal != nil && d.OnGoal() { return } // YES We have a solution

	next, ok := d.OnFail() // ... keep going?

	if !ok { return } // YES We have a failure/dead-end

	//	d.level++
	d.Dance(next)
	//	d.level--
}

// SpinVeryFast keeps a dancer turning to dance dancing or not - but without beating, and without turning OnLeaf nor OnGoal
//  Note: this may be useful only for benchmarks / OnLeaf-counting
func (d *turn) SpinVeryFast() {

	//	if d.OnLeaf() { return } // YES We have to abort
	//	if d.OnGoal() { return } // YES We have a solution - but we don't tell anyone

	next, ok := d.OnFail() // ... keep going?

	if !ok { return } // YES We have a failure/dead-end

	//	d.level++
	d.Dance(next)
	//	d.level--
}
