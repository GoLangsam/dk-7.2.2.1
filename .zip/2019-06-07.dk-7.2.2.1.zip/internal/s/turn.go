// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

// turn is what a dancer during a dance does and does and does.
// It consolidates the functions relevant for controlling its behaviour.
type turn struct {
	OnLeaf func() bool        // YES We have to abort
	OnGoal func() bool        // YES We have a solution
	OnFail func() (int, bool) // YES We have to go on dancing & goaling - may be
	Dance  func(int)          // and We have to dance here now

	verbose bool
}

// ========================================================
