// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

// TurnOnLeaf returns a function which
// sets pace.turn.OnLeaf to v
// and returns it's undo doFn.
func TurnOnLeaf(v func() bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.turn.OnLeaf
		a.pace.turn.OnLeaf = v
		return func() doFn {
			return TurnOnLeaf(prev)(a)
		}
	}
}

// TurnOnGoal returns a function which
// sets pace.turn.OnGoal to v
// and returns it's undo doFn.
func TurnOnGoal(v func() bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.turn.OnGoal
		a.pace.turn.OnGoal = v
		return func() doFn {
			return TurnOnGoal(prev)(a)
		}
	}
}

// TurnOnFail returns a function which
// sets pace.turn.OnFail to v
// and returns it's undo doFn.
func TurnOnFail(v func() (int, bool)) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.turn.OnFail
		a.pace.turn.OnFail = v
		return func() doFn {
			return TurnOnFail(prev)(a)
		}
	}
}

// VerboseTurn returns a function which
// sets pace.turn.verbose to v
// and returns it's undo doFn.
func VerboseTurn(v bool) Setter {
	return func(a *Searcher) doFn {
		prev := a.pace.turn.verbose
		a.pace.turn.verbose = v
		return func() doFn {
			return VerboseTurn(prev)(a)
		}
	}
}
