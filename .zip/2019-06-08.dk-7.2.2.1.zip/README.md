# taocp-7.2.2.1

[![Software License](https://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat-square)](LICENSE.md)
[![Go Report Card](https://goreportcard.com/badge/github.com/GoLangsam/taocp-7.2.2.1)](https://goreportcard.com/report/github.com/GoLangsam/taocp-7.2.2.1)
[![Build Status](https://travis-ci.org/GoLangsam/taocp-7.2.2.1.svg?branch=master)](https://travis-ci.org/GoLangsam/taocp-7.2.2.1)
[![GoDoc](https://godoc.org/github.com/GoLangsam/taocp-7.2.2.1?status.svg)](https://godoc.org/github.com/GoLangsam/taocp-7.2.2.1)

[taocp]()-[7.2.2.1]() provides package [dl]() - what else ;-)

