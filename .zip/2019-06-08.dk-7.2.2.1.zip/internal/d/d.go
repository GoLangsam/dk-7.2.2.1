// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/m"
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// ===========================================================================

type D struct {
	x.ItemS
	x.OptaS
	x.Drum
	x.Stack
	On
}

// New returns a fresh Dancer
// based on data cloned from the given problem Matrix.
func New(M *m.M) D {
	return D{
		ItemS:  M.ItemS.Clone(),
		OptaS:  M.OptaS.Clone(),
		Drum:   x.NewDrum("UpOptaS", len(M.OptaS)),
		Stack:  x.NewStack(-M.OptaS[0].Root), // len(M.ItemS)),
	} // can Dance - implements s.Dancer
}

// ===========================================================================
