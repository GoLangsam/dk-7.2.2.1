// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

// ===========================================================================

func (a *D) DanceFast(i int) {

	var j int          // Dance: item to cover
	var p, x int       // Dance: option-line next/prev, option next/prev
	var c, l, r int    // cover: item(column), left, right
	var q, t, u, d int // hide: pointer, top, up, down

	j = i
	{
		{
			// a.deTachItem(j)
			for c = a.OptaS[j].Next; c != j; c = a.OptaS[c].Next {
				// a.deTach(c)
				q = c + 1
				for q != c { // ForEachOtherNext
					t = a.OptaS[q].Root
					u = a.OptaS[q].Prev
					d = a.OptaS[q].Next

					if t < 0 { // Spacer
						q = u
						continue
					}
					//  a.OptaS.DeTach(q)
					a.OptaS[u].Next = d
					a.OptaS[d].Prev = u
					a.OptaS[t].Root--
					q++

					a.Drum.Cnt++ // count update per Opta
					if a.Drum.Verbose {
						a.Drum.Map[q]++
					}
					if a.On.Leaf != nil { // count update per Level
						a.On.Leaf(len(a.Stack))
					}
				}

			}

			//  a.ItemS.DeTach(j)
			l = a.ItemS[j].Prev
			r = a.ItemS[j].Next
			a.ItemS[l].Next = r
			a.ItemS[r].Prev = l

		}
	}

	for x = a.OptaS[i].Next; x != i; x = a.OptaS[x].Next {

		a.Stack = append(a.Stack, x) // a.Stack.Push(x)

		p = x + 1
		for p != x {
			j = a.OptaS[p].Root
			if j < 0 { // Spacer
				p = a.OptaS[p].Prev
				continue
			}
			// a.deTachItem(j)
			for c = a.OptaS[j].Next; c != j; c = a.OptaS[c].Next {
				// a.deTach(c)
				q = c + 1
				for q != c { // ForEachOtherNext
					t = a.OptaS[q].Root
					u = a.OptaS[q].Prev
					d = a.OptaS[q].Next

					if t < 0 { // Spacer
						q = u
						continue
					}
					//  a.OptaS.DeTach(q)
					a.OptaS[u].Next = d
					a.OptaS[d].Prev = u
					a.OptaS[t].Root--
					q++

					a.Drum.Cnt++ // count update per Opta
					if a.Drum.Verbose {
						a.Drum.Map[q]++
					}
					if a.On.Leaf != nil { // count update per Level
						a.On.Leaf(len(a.Stack))
					}
				}

			}

			//  a.ItemS.DeTach(j)
			l = a.ItemS[j].Prev
			r = a.ItemS[j].Next
			a.ItemS[l].Next = r
			a.ItemS[r].Prev = l

			p++
		}

		a.On.Next()

		p = x - 1
		for p != x {
			j = a.OptaS[p].Root
			if j < 0 { // Spacer
				p = a.OptaS[p].Next
				continue
			}

			// a.reTachItem(j)
			//  a.ItemS.ReTach(j)
			l = a.ItemS[j].Prev
			r = a.ItemS[j].Next
			a.ItemS[l].Next = j
			a.ItemS[r].Prev = j

			for c = a.OptaS[j].Prev; c != j; c = a.OptaS[c].Prev {
				// a.reTach(c)
				q = c - 1
				for q != c { // ForEachOtherPrev
					t = a.OptaS[q].Root
					u = a.OptaS[q].Prev
					d = a.OptaS[q].Next

					if t < 0 { // Spacer
						q = d
						continue
					}
					//  a.OptaS.ReTach(q)
					a.OptaS[u].Next = q
					a.OptaS[d].Prev = q
					a.OptaS[t].Root++
					q--
				}

			}

			p--
		}

		a.Stack = a.Stack[:len(a.Stack)-1] // a.Stack.Drop()

	}

	j = i
	{
		{
			// a.reTachItem(j)
			//  a.ItemS.ReTach(j)
			l = a.ItemS[j].Prev
			r = a.ItemS[j].Next
			a.ItemS[l].Next = j
			a.ItemS[r].Prev = j

			for c = a.OptaS[j].Prev; c != j; c = a.OptaS[c].Prev {
				// a.reTach(c)
				q = c - 1
				for q != c { // ForEachOtherPrev
					t = a.OptaS[q].Root
					u = a.OptaS[q].Prev
					d = a.OptaS[q].Next

					if t < 0 { // Spacer
						q = d
						continue
					}
					//  a.OptaS.ReTach(q)
					a.OptaS[u].Next = q
					a.OptaS[d].Prev = q
					a.OptaS[t].Root++
					q--
				}

			}
		}
	}

}

// ===========================================================================
