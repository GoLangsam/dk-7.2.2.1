
X1. [Initialize.}
	// Set the problem up in memory, as in Table 1. (See exerise 8.)
	// Also set N to the number of items, Z to the last spaer address, and l = 0.

X2. [Enter level l.]
	If RLINK(0) = 0 (hence all items have been covered),
		visit the solution that is specified by
		x[0], x[1], ..., x[l-1] and
	=>	go to X8. (See exerise 13.)

X3. [Choose i.]
		// At this p oint the items i[1] , : : : , i[t] still need to be covered,
		// where i[1] = RLINK(0), i[j+1] = RLINK(i[j]), RLINK(i[t]) = 0.
		// Choose one of them, and call it i.
		i := Choice()
		// (The MRV heuristic of exercise 9 often works well in practice.)

X4. [Cover i.]
	Cover(i) // using (12), and set
	x[l] = DLINK(i).

X5. [Try x[l].]
	If x[l] == i
	=>	go to X7 // (we've tried all options for i).
	// Otherwise set
	p = x[l] + 1

	for p != x[l] {
		Set j TOP(p)
		if j = 0
			set	p = ULINK(p)
	otherwise
		cover(j ) and
		set	p = p + 1.
	} // (This overs the items != i in the option that ontains x[l].)

	Set	l = l + 1 and
	=>	return to X2.

X6. [Try again.]
	p = x[l] - 1
	for p != x[l] {
		Set j = TOP(p)
		if j != 0,
			set	p = DLINK(p)
		otherwise
			uncover(j) and
			set	p = p + 1
	} // (This uncovers the items != i in the option that ontains x[l], using the reverse of the order in X5.)

	Set	i = TOP(x[l])
		x[l] = DLINK(x[l])
	=>	return to X5.

X7. [Backtrack.]
	Unover(i) // using (14).

X8. [Leave level l].
	if l = 0
		Terminate
	Otherwise
		set	l = l - 1 and
	=>	go to X6.
