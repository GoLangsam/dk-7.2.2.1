// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

// ===========================================================================

func (a *D) Dance(i int) {

	var p, x, j int

	j = i
	{
		{
			a.deTachItem(j)
		}
	}

	for x = a.OptaS[i].Next; x != i; x = a.OptaS[x].Next {

		a.Stack = append(a.Stack, x) // a.Stack.Push(x)

		p = x + 1
		for p != x {
			j = a.OptaS[p].Root
			if j < 0 { // Spacer
				p = a.OptaS[p].Prev
				continue
			}
			a.deTachItem(j)
			p++
		}

		a.On.Next()

		p = x - 1
		for p != x {
			j = a.OptaS[p].Root
			if j < 0 { // Spacer
				p = a.OptaS[p].Next
				continue
			}
			a.reTachItem(j)
			p--
		}

		a.Stack = a.Stack[:len(a.Stack)-1] // a.Stack.Drop()

	}

	j = i
	{
		{
			a.reTachItem(j)
		}
	}

}

// ===========================================================================
