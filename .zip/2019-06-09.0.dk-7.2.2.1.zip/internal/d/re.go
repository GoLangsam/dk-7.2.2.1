// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

// ===========================================================================

func (a *D) reTachItem(j int) {
	var c, l, r int // cover: column, left, right

	{
		{

			//  a.ItemS.ReTach(j)
			l = a.ItemS[j].Prev
			r = a.ItemS[j].Next
			a.ItemS[l].Next = j
			a.ItemS[r].Prev = j

			for c = a.OptaS[j].Prev; c != j; c = a.OptaS[c].Prev {
				a.reTach(c)
			}

		}
	}
}

// ===========================================================================

// reTach unhides c.
func (a *D) reTach(c int) {
	var q, t, u, d int // hide: pointer, top, up, down

	{
		{
			{

				q = c - 1
				for q != c { // ForEachOtherPrev
					t = a.OptaS[q].Root
					u = a.OptaS[q].Prev
					d = a.OptaS[q].Next

					if t < 0 { // Spacer
						q = d
						continue
					}
					//  a.OptaS.ReTach(q)
					a.OptaS[u].Next = q
					a.OptaS[d].Prev = q
					a.OptaS[t].Root++
					q--
				}

			}
		}
	}
}

// ===========================================================================
