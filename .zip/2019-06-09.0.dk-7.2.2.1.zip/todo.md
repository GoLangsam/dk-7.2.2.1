- NOTE:
  - tees\cmd\NQueensR.exe -Beg 418 -End 418 -Fast -Sort -s
    gibt erste Lösung in < 10 sec bei N < 420
  - dl\cmd\...
	braucht schon bei N > 64 wesentlich mehr als 10 sec
    gibt erste Lösung in < 10 sec


- TODO: rename repo dk-7.2.2.1 => taocp-7.2.2.1 which provides dl

- TODO: doc.go for each package: x s m d (& l)
  - including TODOs - for liteIDE :-)

- m TODO: create secondary items on demand! (Iff we HAVE primary items!)
- m TODO: make sure, any option contains one primary item (at least)! (Iff we HAVE primary items!)

- m TODO: functions for DK's N, N1, N2, Z, ...

- s TODO: the "non-sharp/sharp preference"-Heuristics: Idea: a Name-Filter-Func

- d TODO: DanceFast: Hide => inline; no UpDate-Counting?
- d TODO: errata.md: recommend renames der local vars

- s TODO: as a process, return
  - a chan<-(Setter) which, when closed, sets isAborting = true
  - a <-chan(Solution) (= Stack.Clone & #-of-not-yet-covered-items)
  - a <-chan(Summary)  (= Drums) to indicate: finished this search

- container TODO: "container/.../drum" - remove, or improve
- tees TODO: "tees/dance/dancers/drummer/drum" - remove, or improve
- Note: "tees/dance/dancers/chooser/" needs verbose.go as it is a function library package

---- tees:README.md

This project is dormant.

I pursue its main purpose elsewhere - using a different data structure.

Dormant it is - neither dead nor archived.

Everything works as advertised; amazing structures can be built and navigated,
waiting to be explored.

I appreciate any feedback/comment/issue/PR of Yours.

new learning - reflected - cleaning - improving

Inspired by [plasicant](???)
