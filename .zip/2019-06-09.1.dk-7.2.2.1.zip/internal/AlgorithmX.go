package test

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/d" // problem matrix
)

func AlgX(a *d.D) {
	// X1. [Initialize.}
	// Set the problem up in memory, as in Table 1. (See exerise 8.)
	// Also set N to the number of items, Z to the last spacer address, and l = 0.

	var l int // level
	var i int // main col
	x := make([]int, len(a.ItemS))

	var j int // some col, arg for Cover
	var p int // option cell

X2: // [Enter level l.]

	if a.OptaS[0].Root == 0 { // (hence all items have been covered),
		// visit the solution that is specified by x[0], x[1], ..., x[l-1] and
		goto X8 // (See exerise 13.)
	}

	// X3: // [Choose i.]
	// At this p oint the items i[1] , : : : , i[t] still need to be covered,
	// where i[1] = RLINK(0), i[j+1] = RLINK(i[j]), RLINK(i[t]) = 0.
	// Choose one of them, and call it i.
	i = a.Choice()
	// (The MRV heuristic of exercise 9 often works well in practice.)
	if a.OptaS[i].Next == i {
		// TODO: we have a Dead end!
	}

	// X4: // [Cover i.]
	j = i
	{
		a.Cover(j) // using (12), and set
	}

	x[l] = a.OptaS[i].Next

X5: // [Try x[l].]
	if x[l] == i {
		goto X7 // (we've tried all options for i).
	} // Otherwise set
	p = x[l] + 1

	for p != x[l] {
		j = a.OptaS[p].Root
		if j < 0 { // Spacer
			p = a.OptaS[p].Prev
			continue
		} // otherwise
		a.Cover(j)
		p = p + 1
	} // (This overs the items != i in the option that ontains x[l].)

	l++ // TODO: panic iff x is too short
	goto X2

X6: // [Try again.]
	p = x[l] - 1
	for p != x[l] {
		j = a.OptaS[p].Root
		if j < 0 { // Spacer
			p = a.OptaS[p].Next
			continue
		} // otherwise
		a.Uncover(j)
		p = p + 1
	} // (This uncovers the items != i in the option that ontains x[l], using the reverse of the order in X5.)

	i = a.OptaS[x[l]].Root
	x[l] = a.OptaS[x[l]].Next
	goto X5

X7: // [Backtrack.]
	j = i
	{
		a.Uncover(j) // using (14).
	}

X8: // [Leave level l].
	if l == 0 {
		return
	} // Otherwise
	l--
	goto X6

}
