// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/m"
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// ===========================================================================

type D struct {
	x.ItemS
	x.OptaS
	x.Drum
	x.Stack
	On
}

// New returns a fresh Dancer
// based on data cloned from the given problem Matrix.
func New(M *m.M) D {
	return D{
		ItemS:  M.ItemS.Clone(),
		OptaS:  M.OptaS.Clone(),
		Drum:   x.NewDrum("UpOptaS", len(M.OptaS)),
		Stack:  x.NewStack(-M.OptaS[0].Root), // len(M.ItemS)),
	} // can Dance - implements s.Dancer
}

// ===========================================================================

func (a *D) Cover(j int) {
	a.deTachItem(j)
}

func (a *D) Uncover(j int) {
	a.reTachItem(j)
}

func (a *D) Choice() (here int) {

	Size := len(a.OptaS) // larger than anything we'll find.

	for curr := a.ItemS[0].Next; curr != 0; curr = a.ItemS[curr].Next {
		size := a.OptaS[curr].Root
		// TODO: the "non-sharp/sharp preference"-Heuristics
		// if a.NameS[curr] does/doesn't start with `#` {
		//	size = size + len(a.Optas.MarkS) - 1 // #-of-options
		// }
		/*
		if size == 0 {
			here, found = -1, false
			break
		}
		*/
		if size < Size {
			Size = size
			here = curr
		//	found = true
		}
	}
		/*
	if a.logChoice { // ... we may show it
		fmt.Println("Chosen:", tab, here, tab, found, tab)
	}
		*/
	return
}