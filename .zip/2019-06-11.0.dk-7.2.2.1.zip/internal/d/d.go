// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package d

import (
	"github.com/GoLangsam/dk-7.2.2.1/internal/m"
	"github.com/GoLangsam/dk-7.2.2.1/internal/x"
)

// ===========================================================================

type D struct {
	Items
	Optas
	Drum
	Stack

	On // what to do when
}

// New returns a fresh Dancer
// based on data cloned from the given problem Matrix.
func New(M *m.M) D {
	return D{
		Items: x.Items{M.ItemS.Clone(), M.Items.MarkS},
		Optas: x.Optas{M.OptaS.Clone(), M.Optas.MarkS},
		Drum:  x.NewDrum("UpOptaS", len(M.OptaS)),
		Stack: x.NewStack(-M.OptaS[0].Root), // len(M.ItemS)),
	} // can dance
}

// ===========================================================================

// Choice returns the index of a primary Item - its Root is index for Dance(i).
//
// It panics iff the list rooted at ItemS[0] is empty.
// TODO: DK Version for AlgX - put elsewhere !!!
func (a *D) Choice() (here Index) {

	Size := len(a.OptaS) // larger than anything we'll find.
	root := &a.ItemS[0]

	var size int
	for curr := root.Next; curr != 0; curr = a.ItemS[curr].Next {
		size = a.OptaS[curr].Root
		// TODO: the "non-sharp/sharp preference"-Heuristics
		// if a.NameS[curr] does/doesn't start with `#` {
		//	size = size + len(a.Optas.MarkS) - 1 // #-of-options
		// }
		/*
			if size == 0 {
				here, found = -1, false
				break
			}
		*/
		if size < Size {
			Size = size
			here = curr
			//	found = true
		}
	}
	/*
		if a.logChoice { // ... we may show it
			fmt.Println("Chosen:", tab, here, tab, found, tab)
		}
	*/
	return
}
