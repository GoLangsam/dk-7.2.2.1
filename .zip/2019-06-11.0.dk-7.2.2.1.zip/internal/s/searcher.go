// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package s

import (
	"fmt"

	"github.com/GoLangsam/dk-7.2.2.1/internal/d" // dancing
	"github.com/GoLangsam/dk-7.2.2.1/internal/m" // problem matrix
)

// ========================================================

// Searcher consolidates what's needed to Search.
type Searcher struct {
	m    *m.M // the problem Matrix - intentionally shadowed
	d.D       // the Dancer - can Dance
	pace      // the Pacer  - can Spin or Turn

	// x.Stack

	logOnDone bool
	logOnGoal bool
	logChoice bool
}

// ========================================================

// New returns (a pointer to) a fresh Searcher
// with silent default settings,
// ready to be formed, and
// ready to Search().
func New(M *m.M, setters ...Setter) *Searcher {

	cap := len(M.ItemS)

	a := new(Searcher)
	a.m = M                      // the problem Matrix
	a.D = d.New(M)               // can Dance - implements Dancer
	a.pace.drums = newDrums(cap) // can Count - Beat the Rhythm

	// a.Stack = x.NewStack(cap)

	a.Settings( // defaults
		OnDone(a.onDone),                   // YES We have to return
		OnGoal(a.onGoal),                   // YES We have a solution
		SetChooser(a.chooseMRV),            // YES We have to go on dancing & goaling
		SetPacer(a.pace.Spin),              // ... here we spin & turn
		SetDancer(a.D.Dance),               // ... here links dance
		SetDancer(a.D.DanceFast),           // ... here links dance faster
		CallOnLeaf(a.pace.drums.leaf.Beat), // Count updates
	)

	a.Settings( // user settings
		setters...)

	return a
}

// ========================================================

// Search is what a Searcher is busy doing.
func (a *Searcher) Search() *Searcher {
	a.D.On.Next()
	return a
}

// ========================================================

// Print prints results of a Search
// depending on the verbosity settings.
//
// Per default: nothing is printed.
func (a *Searcher) Print() *Searcher {
	a.D.Drum.Print()
	a.pace.drums.Print()
	return a
}

// ========================================================

// Default methods

func (a *Searcher) onDone() bool { // Do we have to return?
	if a.logOnDone { // TODO: What to print?
		// d.Stacker.Top().PrintValue("Stack-Top")
		// l.PrintValue()
		// l.PrintAways()
	}
	return false
}

// ========================================================

func (a *Searcher) onGoal() bool { // Do we have a solution?
	if a.ItemS[0].Next == 0 { // YES We have a solution
		if a.logOnGoal { // ... we may show it
			fmt.Println("Solution:")
			show := func(i int) { fmt.Print(a.m.NameS[a.OptaS[i].Root], tab) }
			do := a.m.Do(show)
			for _, opta := range a.Stack {
				// show(opta)
				do.ForEachLineNext(opta)
				fmt.Println()
			}
		}
		return true
	}

	return false
}

// ========================================================

// chooseMRV searches the next item to be considered (if any).
// It implements the MRV heuristic.
func (a *Searcher) chooseMRV() (here int, found bool) {

	Size := len(a.OptaS) // larger than anything we'll find.

	for curr := a.ItemS[0].Next; curr != 0; curr = a.ItemS[curr].Next {
		size := a.OptaS[curr].Root
		// TODO: the "non-sharp/sharp preference"-Heuristics
		// if a.NameS[curr] does/doesn't start with `#` {
		//	size = size + len(a.Optas.MarkS) - 1 // #-of-options
		// }
		if size == 0 {
			here, found = -1, false
			break
		}
		if size < Size {
			Size = size
			here = curr
			found = true
		}
	}
	if a.logChoice { // ... we may show it
		fmt.Println("Chosen:", tab, here, tab, found, tab)
	}
	return
}

// ========================================================
