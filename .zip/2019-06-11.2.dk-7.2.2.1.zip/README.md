# dk-7.2.2.1

[![Software License](https://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat-square)](LICENSE.md)
[![Go Report Card](https://goreportcard.com/badge/github.com/GoLangsam/dk-7.2.2.1)](https://goreportcard.com/report/github.com/GoLangsam/dk-7.2.2.1)
[![Build Status](https://travis-ci.org/GoLangsam/dk-7.2.2.1.svg?branch=master)](https://travis-ci.org/GoLangsam/dk-7.2.2.1)
[![GoDoc](https://godoc.org/github.com/GoLangsam/dk-7.2.2.1?status.svg)](https://godoc.org/github.com/GoLangsam/dk-7.2.2.1)

[dk]()-[7.2.2.1]() provides package [dl]() - what else ;-)

